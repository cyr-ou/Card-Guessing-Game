'''
Chen Chen
540562833
yche0422
'''
# USYD CODE CITATION ACKNOWLEDGEMENT
# I declare that the following code is my own work

# Define constant variable
VAL_RANK = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "10": 10,
            "Jack": 11, "Queen": 12, "King": 13, "Ace": 14}
SUIT_RANK = {"Clubs": 1, "Diamonds": 2, "Hearts": 3, "Spades": 4}

def guessing_card(opponent_card: tuple[str, str],lowest_card: tuple[str, str], highest_card: tuple[str, str]) -> None:

    lowest_card_value,lowest_card_suit = lowest_card
    highest_card_value,highest_card_suit = highest_card

    user_input = input(f'Guess the card on the opponent\'s hand [({lowest_card_value},{lowest_card_suit}), ({highest_card_value},{highest_card_suit})]: ').strip()
    
    guessed_card_value = user_input.split(',')[0].strip().capitalize()
    guessed_card_suit = user_input.split(',')[1].strip().capitalize()
    user_guessing = (guessed_card_value,guessed_card_suit)

    opponent_card_value = VAL_RANK[opponent_card[0]]
    opponent_card_suit = SUIT_RANK[opponent_card[1]]
    guessed_card_value_rank = VAL_RANK[guessed_card_value]
    guessed_card_suit_rank = SUIT_RANK[guessed_card_suit]

    if user_guessing == opponent_card:
        print('Correct! You found the card!')
        return
    elif guessed_card_value_rank > opponent_card_value or (guessed_card_value_rank == opponent_card_value and guessed_card_suit_rank > opponent_card_suit):
        print('The guessed card is too high :((\n')
        highest_card = user_guessing
        for suit,rank in SUIT_RANK.items():
            if rank == guessed_card_suit_rank - 1:
                highest_card = (guessed_card_value, suit)
                break
    elif guessed_card_value_rank < opponent_card_value or (guessed_card_value_rank == opponent_card_value and guessed_card_suit_rank < opponent_card_suit):
        print('The guessed card is too low :((\n')
        lowest_card = user_guessing
        for suit, rank in SUIT_RANK.items():
            if rank == guessed_card_suit_rank + 1:
                lowest_card = (guessed_card_value, suit)
                break

    guessing_card(opponent_card, lowest_card, highest_card) # recursive case

import sys

def main():
    if len(sys.argv) != 3:
        print('Undefined card from opponent :((')
        sys.exit(1)

    opponent_card_value = sys.argv[1].capitalize()
    opponent_card_suit = sys.argv[2].capitalize()
    opponent_card = (opponent_card_value,opponent_card_suit)

    lowest_card_value = '2'
    lowest_card_suit = 'Clubs'
    lowest_card = (lowest_card_value, lowest_card_suit)

    highest_card_value = 'Ace'
    highest_card_suit = 'Spades'
    highest_card = (highest_card_value, highest_card_suit)  

    guessing_card(opponent_card, lowest_card, highest_card) # calling function
    
if __name__ == '__main__':
    main()
